-- Copyright (C) Yichun Zhang (agentzh)


-- FIXME: this library is very rough and is currently just for testing
--        the websocket server.


local wbproto = require "resty.websocket.protocol"
local bit = require "bit"


local _recv_frame = wbproto.recv_frame
local _send_frame = wbproto.send_frame
local new_tab = wbproto.new_tab
local tcp = ngx.socket.tcp
local re_match = ngx.re.match
local re_find  = ngx.re.find
local re_gmatch = ngx.re.gmatch
local re_gsub = ngx.re.gsub
local str_lower = string.lower
local sub = string.sub
local sha1_bin = ngx.sha1_bin
local encode_base64 = ngx.encode_base64
local concat = table.concat
local char = string.char
local byte = string.byte
local str_find = string.find
local rand = math.random
local rshift = bit.rshift
local band = bit.band
local setmetatable = setmetatable
local type = type
local pairs = pairs
local debug = ngx.config.debug
local ngx_log = ngx.log
local ngx_DEBUG = ngx.DEBUG
local assert = assert
local ssl_support = true

if not ngx.config
    or not ngx.config.ngx_lua_version
    or ngx.config.ngx_lua_version < 9011
then
    ssl_support = false
end

local _M = new_tab(0, 13)
_M._VERSION = '0.13'


local mt = { __index = _M }


local handshake_headers = {
    upgrade = true,
    connection = true,
    ["sec-websocket-accept"] = true,
    ["sec-websocket-protocol"] = true,
    ["sec-websocket-extensions"] = true,
}


function _M.new(self, opts)
    local sock, err = tcp()
    if not sock then
        return nil, err
    end

    local max_payload_len, send_unmasked, timeout
    local max_recv_len, max_send_len
    if opts then
        max_payload_len = opts.max_payload_len
        max_recv_len = opts.max_recv_len
        max_send_len = opts.max_send_len

        send_unmasked = opts.send_unmasked
        timeout = opts.timeout

        if timeout then
            sock:settimeout(timeout)
        end
    end

    max_payload_len = max_payload_len or 65535
    max_recv_len = max_recv_len or max_payload_len
    max_send_len = max_send_len or max_payload_len

    return setmetatable({
        sock = sock,
        recv_state = {},
        max_recv_len = max_recv_len,
        max_send_len = max_send_len,
        send_unmasked = send_unmasked,
    }, mt)
end


local function trim_ows(value)
    local from, to = 1, #value
    while from <= to do
        local c = byte(value, from)
        if c ~= 32 and c ~= 9 then
            break
        end

        from = from + 1
    end

    while to >= from do
        local c = byte(value, to)
        if c ~= 32 and c ~= 9 then
            break
        end

        to = to - 1
    end

    return sub(value, from, to)
end


local function has_token(value, token, ignore_case)
    if not value then
        return false
    end

    local from = 1
    while true do
        local comma = str_find(value, ",", from, true)
        local part = trim_ows(sub(value, from, comma and comma - 1 or #value))
        if ignore_case then
            part = str_lower(part)
        end

        if part == token then
            return true
        end

        if not comma then
            return false
        end

        from = comma + 1
    end
end


local function unfold_headers(value)
    if not str_find(value, "\r\n ", 1, true)
       and not str_find(value, "\r\n\t", 1, true)
    then
        return value
    end

    local unfolded, _, err = re_gsub(value, [[\r\n[ \t]+]], " ", "jo")
    if not unfolded then
        return nil, err
    end

    return unfolded
end


local function has_protocol(request, protocol)
    local from, _, err = re_find(protocol,
        [[\A[!#$%&'*+\-.^_`|~0-9A-Za-z]+\z]], "jo")
    if err then
        return nil, err
    end

    if not from then
        return false
    end

    request, err = unfold_headers(request)
    if not request then
        return nil, err
    end

    local iter, err = re_gmatch(request,
        [[\r\nSec-WebSocket-Protocol:[ \t]*([^\r\n]*)]], "ijo")
    if not iter then
        return nil, err
    end

    while true do
        local m, err = iter()
        if err then
            return nil, err
        end

        if not m then
            return false
        end

        if has_token(m[1], protocol, false) then
            return true
        end
    end
end


local function fail_handshake(self, err, header)
    self.sock:close()
    self.sock = nil
    return nil, err, header
end


function _M.connect(self, uri, opts)
    local sock = self.sock
    if not sock then
        return nil, "not initialized"
    end

    local is_unix = false

    local m, err
    if re_find(uri, "unix:") then
        is_unix = true
        m, err = re_match(uri, [[^(wss?)://(unix:[^:]+):()(.*)]], "jo")
    else
        m, err = re_match(uri, [[^(wss?)://([^:/]+)(?::(\d+))?(.*)]], "jo")
    end

    if not m then
        if err then
            return nil, "failed to match the uri: " .. err
        end

        return nil, "bad websocket uri"
    end

    local scheme = m[1]
    local addr = m[2]
    local port = m[3]
    local path = m[4]

    -- ngx.say("host: ", host)
    -- ngx.say("port: ", port)

    local ssl = scheme == "wss"
    if ssl and not ssl_support then
        return nil, "ngx_lua 0.9.11+ required for SSL sockets"
    end

    if not port then
        port = ssl and 443 or 80
    end

    if path == "" then
        path = "/"
    end

    local ssl_verify, server_name, headers, proto_header, origin_header
    local sock_opts = {}
    local client_cert, client_priv_key
    local header_host
    local key

    if opts then
        local protos = opts.protocols
        if protos then
            if type(protos) == "table" then
                proto_header = "\r\nSec-WebSocket-Protocol: "
                               .. concat(protos, ",")

            else
                proto_header = "\r\nSec-WebSocket-Protocol: " .. protos
            end
        end

        local origin = opts.origin
        if origin then
            origin_header = "\r\nOrigin: " .. origin
        end

        if opts.pool then
            sock_opts.pool = opts.pool
        end
        --pool_size specify the size of the connection pool. If omitted and no backlog option was provided, no pool will be created.
        if opts.pool_size then
            sock_opts.pool_size = opts.pool_size
        end
        if opts.backlog then
            sock_opts.backlog = opts.backlog
        end


        client_cert = opts.client_cert
        client_priv_key = opts.client_priv_key

        if client_cert then
            assert(client_priv_key,
                   "client_priv_key must be provided with client_cert")
        end

        ssl_verify = opts.ssl_verify

        server_name = opts.server_name
        if server_name ~= nil and type(server_name) ~= "string" then
            return nil, "SSL server_name must be a string"
        end

        if opts.headers then
            headers = opts.headers
            if type(headers) ~= "table" then
                return nil, "custom headers must be a table"
            end
        end

        header_host = opts.host
        if header_host ~= nil and type(header_host) ~= "string" then
            return nil, "custom host header must be a string"
        end

        key = opts.key
        if key ~= nil and type(key) ~= "string" then
            return nil, "custom Sec-WebSocket-Key must be a string"
        end
    end

    local ok, err
    if is_unix then
        ok, err = sock:connect(addr, sock_opts)
    else
        ok, err = sock:connect(addr, port, sock_opts)
    end
    if not ok then
        return nil, "failed to connect: " .. err
    end

    self.recv_state = {}

    -- check for connections from pool:
    local reused_count, err = sock:getreusedtimes()
    if not reused_count then
        return nil, "failed to get reused times: " .. tostring(err)
    end

    if reused_count > 0 then
        -- being a reused connection (must have done handshake)
        return 1, nil, "connection reused"
    end

    if ssl then
        if client_cert then
            ok, err = sock:setclientcert(client_cert, client_priv_key)
            if not ok then
                return nil, "failed to set TLS client certificate: " .. err
            end
        end

        server_name = server_name or header_host or addr

        ok, err = sock:sslhandshake(false, server_name, ssl_verify)
        if not ok then
            return nil, "ssl handshake failed: " .. err
        end
    end

    local custom_headers
    if headers then
        custom_headers = concat(headers, "\r\n")
        custom_headers = "\r\n" .. custom_headers
    end

    -- do the websocket handshake:

    if not key then
        local bytes = char(rand(256) - 1, rand(256) - 1, rand(256) - 1,
                           rand(256) - 1, rand(256) - 1, rand(256) - 1,
                           rand(256) - 1, rand(256) - 1, rand(256) - 1,
                           rand(256) - 1, rand(256) - 1, rand(256) - 1,
                           rand(256) - 1, rand(256) - 1, rand(256) - 1,
                           rand(256) - 1)

        key = encode_base64(bytes)
    end

    local host_header = header_host 
                        or (is_unix and "unix_sock" or addr .. ":" .. port)

    local req = "GET " .. path .. " HTTP/1.1\r\nUpgrade: websocket\r\nHost: "
                .. host_header
                .. "\r\nSec-WebSocket-Key: " .. key
                .. (proto_header or "")
                .. "\r\nSec-WebSocket-Version: 13"
                .. (origin_header or "")
                .. "\r\nConnection: Upgrade"
                .. (custom_headers or "")
                .. "\r\n\r\n"

    local bytes, err = sock:send(req)
    if not bytes then
        return fail_handshake(self, "failed to send the handshake request: "
                                    .. err)
    end

    local header_reader = sock:receiveuntil("\r\n\r\n")
    -- FIXME: check for too big response headers
    local header, err, partial = header_reader()
    if not header then
        return fail_handshake(self, "failed to receive response header: " .. err)
    end

    -- error("header: " .. header)

    m, err = re_match(header, [[^\s*HTTP/1\.1\s+(\d+)]], "jo")
    if not m then
        return fail_handshake(self, "bad HTTP response status line: " .. header)
    end

    -- RFC 6455 section 4.1: a status code other than 101 means the server
    -- has not accepted the upgrade, so the client must fail the connection
    if m[1] ~= "101" then
        return fail_handshake(self,
                              "failed websocket handshake: "
                              .. "unexpected response status: "
                              .. m[1], header)
    end

    local unfolded_header, err = unfold_headers(header)
    if not unfolded_header then
        return fail_handshake(self, "failed to parse response headers: " .. err,
                              header)
    end

    local response_headers = {}
    local iter, err = re_gmatch(unfolded_header,
        [[\r\n([^:\r\n]+):([^\r\n]*)(?=\r\n|$)]], "jo")
    if not iter then
        return fail_handshake(self, "failed to parse response headers: " .. err,
                              header)
    end

    while true do
        local m, err = iter()
        if err then
            return fail_handshake(self, "failed to parse response headers: "
                                        .. err, header)
        end

        if not m then
            break
        end

        local name = str_lower(m[1])
        if handshake_headers[name] then
            local values = response_headers[name]
            if not values then
                values = {}
                response_headers[name] = values
            end

            values[#values + 1] = trim_ows(m[2])
        end
    end

    for name, values in pairs(response_headers) do
        response_headers[name] = concat(values, ",")
    end

    if not has_token(response_headers.upgrade, "websocket", true) then
        return fail_handshake(self, "failed websocket handshake: "
                              .. "bad Upgrade header",
                              header)
    end

    if not has_token(response_headers.connection, "upgrade", true) then
        return fail_handshake(self, "failed websocket handshake: "
                              .. "bad Connection header",
                              header)
    end

    local accept = encode_base64(sha1_bin(key
                   .. "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"))
    if response_headers["sec-websocket-accept"] ~= accept then
        return fail_handshake(self,
                              "failed websocket handshake: "
                              .. "bad Sec-WebSocket-Accept header",
                              header)
    end

    local protocol = response_headers["sec-websocket-protocol"]
    if protocol then
        local offered, err = has_protocol(req, protocol)
        if err then
            return fail_handshake(self, "failed to parse request headers: "
                                        .. err, header)
        end

        if not offered then
            return fail_handshake(self,
                                  "failed websocket handshake: "
                                  .. "bad Sec-WebSocket-Protocol header",
                                  header)
        end
    end

    if response_headers["sec-websocket-extensions"] then
        return fail_handshake(self,
                              "failed websocket handshake: "
                              .. "unexpected Sec-WebSocket-Extensions header",
                              header)
    end

    return 1, nil, header
end


function _M.set_timeout(self, time)
    local sock = self.sock
    if not sock then
        return nil, nil, "not initialized yet"
    end

    return sock:settimeout(time)
end


function _M.recv_frame(self)
    if self.fatal then
        return nil, nil, "fatal error already happened"
    end

    local sock = self.sock
    if not sock then
        return nil, nil, "not initialized yet"
    end

    local data, typ, err = _recv_frame(sock, self.max_recv_len, false,
                                       self.recv_state)
    if not data and not str_find(err, ": timeout", 1, true) then
        self.fatal = true
    end
    return data, typ, err
end


local function send_frame(self, fin, opcode, payload)
    if self.fatal then
        return nil, "fatal error already happened"
    end

    if self.closed then
        return nil, "already closed"
    end

    local sock = self.sock
    if not sock then
        return nil, "not initialized yet"
    end

    local bytes, err = _send_frame(sock, fin, opcode, payload,
                                   self.max_send_len,
                                   not self.send_unmasked)
    if not bytes then
        self.fatal = true
    end
    return bytes, err
end
_M.send_frame = send_frame


function _M.send_text(self, data)
    return send_frame(self, true, 0x1, data)
end


function _M.send_binary(self, data)
    return send_frame(self, true, 0x2, data)
end


local function send_close(self, code, msg)
    local payload
    if code then
        if type(code) ~= "number" or code > 0x7fff then
            return nil, "bad status code"
        end
        payload = char(band(rshift(code, 8), 0xff), band(code, 0xff))
                        .. (msg or "")
    end

    if debug then
        ngx_log(ngx_DEBUG, "sending the close frame")
    end

    local bytes, err = send_frame(self, true, 0x8, payload)

    if not bytes then
        self.fatal = true
    end

    self.closed = true

    return bytes, err
end
_M.send_close = send_close


function _M.send_ping(self, data)
    return send_frame(self, true, 0x9, data)
end


function _M.send_pong(self, data)
    return send_frame(self, true, 0xa, data)
end


function _M.close(self)
    if self.fatal then
        return nil, "fatal error already happened"
    end

    local sock = self.sock
    if not sock then
        return nil, "not initialized"
    end

    if not self.closed then
        local bytes, err = send_close(self)
        if not bytes then
            return nil, "failed to send close frame: " .. err
        end
    end

    self.recv_state = {}
    return sock:close()
end


function _M.set_keepalive(self, ...)
    if self.fatal then
        return nil, "fatal error already happened"
    end

    if self.recv_state[1] then
        return nil, "cannot pool a partially received frame"
    end

    local sock = self.sock
    if not sock then
        return nil, "not initialized"
    end

    return sock:setkeepalive(...)
end


return _M
