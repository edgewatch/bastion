[![OWASP Flagship](https://img.shields.io/badge/owasp-flagship%20project-38a047.svg)](https://owasp.org/projects/)
[![CII Best Practices](https://www.bestpractices.dev/projects/1390/badge)](https://www.bestpractices.dev/projects/1390)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

| Branch | Status |
|--------|--------|
| main   | ![Regression Tests](https://github.com/coreruleset/coreruleset/actions/workflows/test.yml/badge.svg?branch=main) |

# 🛡️ OWASP CRS

The OWASP CRS is a set of generic attack detection rules for use with [OWASP ModSecurity](https://www.modsecurity.org/), [OWASP Coraza](https://coraza.io/), or other compatible web application firewalls. The CRS aims to protect web applications from a wide range of attacks, including the OWASP Top Ten, with a minimum of false alerts.

## 📚 CRS Resources, Related Projects and Tools

Please see the [OWASP CRS page](https://coreruleset.org/) to get introduced to CRS and view resources on installation, configuration, and working with CRS. There you can also find a [list of projects related to CRS](https://coreruleset.org/) and a [list of tools](https://coreruleset.org/docs/6-development/6-6-useful_tools/) for both developers and users.

## 🤝 Contributing to CRS

We strive to make the OWASP CRS accessible to a wide audience of beginner and experienced users. We are interested in hearing any bug reports, false-positive alert reports, evasions, usability issues, and suggestions for new detections.

- 🐛 [Create an issue on GitHub](https://github.com/coreruleset/coreruleset/issues) to report a false positive or false negative (evasion). Please include your installed version and the relevant portions of your audit log. We will try and address your issue and potentially ask for additional information to reproduce your problem. Please also note that stale issues will be flagged and closed after 120 days. You can search for stale issues with the following [search query](https://github.com/coreruleset/coreruleset/issues?q=label%3A%22Stale+issue%22).

- 💬 [Sign up for our Google Group](https://groups.google.com/a/owasp.org/g/modsecurity-core-rule-set-project) to ask general usage questions and participate in discussions on the CRS.

- 💬 [Join the #coreruleset channel on OWASP Slack](https://owasp.slack.com/) to chat about the CRS. ([Click here](https://owasp.org/slack/invite) to get an invitation if you are not yet registered on the OWASP Slack. It's open to non-members too.)

- 📖 Read also our documentation on [how to contribute](./CONTRIBUTING.md).

## 📄 License

Copyright (c) 2006-2020 Trustwave and contributors. All rights reserved.<br>
Copyright (c) 2021-2026 CRS project. All rights reserved.

The OWASP CRS is distributed under Apache Software License (ASL) version 2. Please see the enclosed LICENSE file for full details.
