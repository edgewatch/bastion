#!/bin/sh
# Añade los binarios de OpenResty al PATH del sistema.
case ":${PATH}:" in
    *:/usr/local/openresty/bin:*) ;;
    *) export PATH="/usr/local/openresty/bin:/usr/local/openresty/nginx/sbin:${PATH}" ;;
esac
